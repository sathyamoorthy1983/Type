package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import tests.LoginTest;
import Pages.Address;
import Pages.Loginpage;
import Pages.Inboxpage;


public class InboxTest extends Loginpage
{	
	
    static WebDriver driver;
	
	
	public InboxTest(WebDriver driver)
	{
		super(driver);
		//this.driver=driver;
	}
	@DataProvider
	public  static Object[][] dd()
	{
		return LoginTest.readData();
		
	}

	//static WebDriver driver;
	
	@Test(dataProvider ="dd")
	public Address click(String username,String password) throws InterruptedException
	{
		LoginTest ll=PageFactory.initElements(driver, LoginTest.class);
		Inboxpage in=ll.checkvaliduser(username,password);
	Address ad=	in.mailclick();
		return ad;
		
		
	}
}