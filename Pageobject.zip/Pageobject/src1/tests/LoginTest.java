package tests;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Assume;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Helper.BrowserFactory;
import Pages.Inboxpage;
import Pages.Loginpage;
import Utils.TestUtils;


public class LoginTest  {
		

	
	
	 @DataProvider
	public static  Object[][] readData() 
	{
		if(TestUtils.IsSkipped("LoginTest"))
		{
			Assume.assumeTrue(false);
		}
		return TestUtils.readTestData("LoginTest");
	}
	 

@Test(dataProvider ="readData")
public Inboxpage checkvaliduser(String username,String password) throws InterruptedException
{

WebDriver driver= BrowserFactory.startbrowser("chrome", "http://www.rediff.com/");

Loginpage Login1=PageFactory.initElements(driver, Loginpage.class);

Inboxpage inbox=Login1.loginrediff(username,password);
Assert.assertEquals(driver.getTitle(), "Rediffmail");

System.out.println(driver.getCurrentUrl());

return inbox;

	
	
}
	 }