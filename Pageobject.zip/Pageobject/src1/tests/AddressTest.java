package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pages.Address;
import Pages.Inboxpage;

public class AddressTest extends Inboxpage {
 static WebDriver driver;
	
	
	public AddressTest(WebDriver driver)
	{
		super(driver);
		//this.driver=driver;
	}
	@DataProvider
	public static Object[][] ddd()
	{
		return LoginTest.readData();
		
	}

	//static WebDriver driver;
	
	@Test(dataProvider ="ddd")
	public static void mm(String username, String password) throws InterruptedException
	{
InboxTest ii=PageFactory.initElements(driver, InboxTest.class);

Address add=ii.click(username,password);
add.cc();
}
}